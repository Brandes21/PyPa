# PSL Tracer package
This package includes 2 python functions that together are able to extract the topological skeleton of the stress tensor field in the rhino environment. 

## Topo_Tracer_1
This function locates degenerate points and calculates the separating direction for each of them.


## Topo_Tracer_1
This function takes the calculated separating directions and traces the separatrices.







For any questions feel free to contact me!